﻿namespace CommUnityWeb.Models
{
    public class User
    {
    }
}
